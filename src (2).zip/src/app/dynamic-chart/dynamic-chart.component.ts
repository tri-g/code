import { Component, OnInit } from '@angular/core';
import * as Highcharts from 'highcharts';
import more from 'highcharts/highcharts-more';
more(Highcharts);
import HighchartsNetworkgraph from 'highcharts/modules/networkgraph'; 
HighchartsNetworkgraph(Highcharts);
import { ResultModel } from './../result-model';
import { PersonaService } from '../persona.service';
import {Demographics} from "./../demo";

@Component({
  selector: 'app-dynamic-chart',
  templateUrl: './dynamic-chart.component.html',
  styleUrls: ['./dynamic-chart.component.css']
})
export class DynamicChartComponent implements OnInit {
 public message:any;
 public id:any;
  public name:any;

   public CategoryModel: ResultModel[];
    title = "Categories";
    chart;
    updateFromInput = false;
    Highcharts = Highcharts;
    chartConstructor = "chart";
    chartCallback;
    chartOptions = {
      chart: {
        type: "networkgraph",
        height: "100%"
      },
      title: {
        text: ""
      },
      plotOptions: {
        networkgraph: {
          keys: ["from", "to"],
          layoutAlgorithm: {
            enableSimulation: true
          }
        }
      },
      series: []
    };

    constructor(private pservice: PersonaService) {
      const self = this;
      this.chartCallback = chart => {
        self.chart = chart;
        this.onInitChart();
      };
    }
   ngOnInit() {

  }

   onInitChart() {
  //debugger
 
this.message=this.pservice.readMessage();
      console.log("hey im here!!!!!!!!!!!!!!!!!!!");
      console.log(this.message);
     for(let details of this.message){
     this.id=details.client_id;
     this.name=details.first;
     }


console.log(this.id);




  this.pservice.categorytop5(this.id).subscribe(
    response => {
        this.CategoryModel = response;
      });
        const self = this,
        chart = this.chart;
    
        chart.showLoading();
        setTimeout(() => {
          chart.hideLoading();
    
          self.chartOptions.series = [
            {
                dataLabels: {
                  enabled: true,
                  linkFormat: '',
                  allowOverlap: true,
                  showInLegend: true
                },
                marker: {
                    radius: 55,
                  },
                nodes: [
                   
                   {
                    id: this.CategoryModel[0].CATEGORY,
                    color: 'red',
              
                  }, {
                    id: this.CategoryModel[1].CATEGORY,
                    color: 'orange'
                  },
                  {
                    id: this.CategoryModel[2].CATEGORY,
                    color: 'green'
                  },
                  {
                    id: this.CategoryModel[3].CATEGORY,
                    color: 'blue'
                  },
                  {
                    id: this.CategoryModel[4].CATEGORY,
                    color: 'pink'
                  }
                  ],
                data: [
                  [this.name, this.CategoryModel[0].CATEGORY],
                  [this.name, this.CategoryModel[1].CATEGORY],
                  [this.name, this.CategoryModel[2].CATEGORY],
                  [this.name, this.CategoryModel[3].CATEGORY],
                  [this.name, this.CategoryModel[4].CATEGORY]
                ]
              }
          ];
    
          self.updateFromInput = true;
        }, 2000);
      }
  }
