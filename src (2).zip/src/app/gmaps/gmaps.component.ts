import {  Component, OnInit, ViewChild, ElementRef, Input } from '@angular/core';
import { ActivatedRoute,Router } from '@angular/router';
import { HttpClient} from '@angular/common/http';
import { PersonaService } from '../persona.service';
import { Observable } from 'rxjs';
import {Locations} from "./../locations";
import {latLng, MapOptions, tileLayer, Map, Marker, icon} from 'leaflet';
import {DEFAULT_LATITUDE, DEFAULT_LONGITUDE} from '../app.constants';
@Component({
  selector: 'app-gmaps',
  templateUrl: './gmaps.component.html',
  styleUrls: ['./gmaps.component.css']
})
export class GmapsComponent {
 public message:any;
 public id:any;
map: Map;
  mapOptions: MapOptions;
  
  lastLayer: any;
  constructor(private router: Router, private route: ActivatedRoute,private http: HttpClient, private pservice:PersonaService) { }

  ngOnInit(){
 this.initializeMapOptions();
 this.getmapsdata();
    }

    getmapsdata(): void {
    this.message=this.pservice.readMessage();
      console.log("hey im here!!!!!!!!!!!!!!!!!!!");
      console.log(this.message);
     for(let details of this.message){
     this.id=details.client_id;
     }
     console.log(this.id);
      this.pservice.categorytop5(this.id).subscribe((data:any) => {
        const lat = data.map(data => data.TRANS_LATITUDE);
      
      const lon = data.map(data => data.TRANS_LONGITUDE);
     
      const cat = data.map(data => data.CATEGORY);
    const amt = data.map(data => data.AMOUNT);
    console.log(amt);
      for(var i=0;i<lat.length;i++)
      this.addSampleMarker(lat[i],lon[i],cat[i],amt[i]);
      });
    }
     
  onMapReady(map: Map) {
    this.map = map;
    //this.addSampleMarker();
  }

  private initializeMapOptions() {
    this.mapOptions = {
      center: [DEFAULT_LATITUDE, DEFAULT_LONGITUDE],
      zoom: 2,
      maxBounds:[[-100,-200],[90,100]],
      layers: [
        tileLayer(
          'http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
          {
            maxZoom: 50,
            attribution: ' '
          })
      ],
    };
  }

  private addSampleMarker(lat,lon,cat,amt) {
      const marker = new Marker([lat, lon])
      .setIcon(
        icon({
          iconSize: [25, 41],
          iconAnchor: [13, 41],
          iconUrl: 'leaflet/marker-icon.png'
        }));
    marker.addTo(this.map);
    this.map.getZoom();

    marker.bindPopup("<b>"+cat+"<br>"+lat+"<br>"+lon+"<br>"+amt+"<b>").openPopup();
  }
}